package br.edu.ifsc.fln.model.domain.ordemServicos;

public enum EStatus {
    ABERTA,
    FECHADA,
    CANCELADA
}

