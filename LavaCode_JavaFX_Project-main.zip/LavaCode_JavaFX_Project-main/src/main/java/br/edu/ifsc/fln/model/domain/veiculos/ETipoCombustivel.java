package br.edu.ifsc.fln.model.domain.veiculos;

// Enumeração TipoCombustivel
public enum ETipoCombustivel
{
        GASOLINA,
        ETANOL,
        FLEX,
        DIESEL,
        GNV,
        ELETRICO,
        OUTRO

}
