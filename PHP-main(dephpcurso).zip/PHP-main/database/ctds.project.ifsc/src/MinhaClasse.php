<?php
namespace Hayden\CtdsProjectIfsc;

class MinhaClasse
{
    public function somar($a, $b)
    {
        return $a + $b;
    }
}