// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    console.log('Página de Em Construção carregada!');
});
