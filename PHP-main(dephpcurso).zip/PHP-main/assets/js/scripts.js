// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    // Adicione aqui qualquer código JavaScript que queira executar após a página ser carregada
    console.log('Welcome to PHP Web Development Wonderland!');
});
