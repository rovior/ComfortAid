package edu.ifsc.fln.confortaid.exception;

public class HorarioOcupadoException extends RuntimeException {
    public HorarioOcupadoException(String message) {
        super(message);
    }
}


